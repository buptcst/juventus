package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.User;
import com.example.demo.service.DemoService;

@RestController
public class DemoController {

	@Autowired
	private DemoService demoService;

	@RequestMapping("/QueryDemo")
	public String getDemos() {
		return demoService.getDemos();
	}
	
	@RequestMapping("/QueryUser")
	public User getUser() {
		return demoService.getUser();
	}
	
	@RequestMapping("/QueryUserList")
	public List<User> getUserList() {
		return demoService.getUserList();
	}
	
	@RequestMapping(value="/QueryUserGroup/{username}" , method = RequestMethod.GET)
	public String getUserGroup(@PathVariable("username") String username) {
		return demoService.getUserGroup(username);
	}
	
	@RequestMapping(value="/QueryTeamTokenNo/{teamname}" , method = RequestMethod.GET)
	public int getTeamTokenNo(@PathVariable("teamname") String teamname) {
		return demoService.getTeamTokenNo(teamname);
	}
	
	
	//how to put the number?
	@RequestMapping(value="/UpdateTeamTokenNo/{teamname}" , method = RequestMethod.PUT)
	public String updateTeamTokenNo(@PathVariable("teamname") String teamname) {
		return demoService.updateTeamTokenNo(teamname);
	}	
	
	//how to match teamname and number
	@RequestMapping(value="/QueryAllTeamTokenNos" , method = RequestMethod.GET)
	public String getAllTeamTokenNos() {
		return demoService.getAllTeamTokenNos();
	}
	
	

}
