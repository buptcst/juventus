package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.entity.User;

@Service
public class DemoService {

	public String getDemos() {
		return "I love Oracle";
	}

	public User getUser() {
		User u = new User();
		u.setUid(1);
		u.setUsername("Daniel");
		u.setPassword("ILoveTJ");
		u.setTeamName("WI");
		u.setGroupName("Admin");
		return u;
	}

	public List<User> getUserList() {
		User u = new User();
		u.setUid(1);
		u.setUsername("Daniel");
		u.setPassword("ILoveTJ");
		u.setTeamName("WI");
		u.setGroupName("Admin");

		User v = new User();
		v.setUid(2);
		v.setUsername("Vivian");
		v.setPassword("ILoveSC");
		v.setTeamName("PI");
		v.setGroupName("Lead");

		List<User> ul = new ArrayList<User>();
		ul.add(u);
		ul.add(v);
		return ul;
	}

	public String getUserGroup(String username) {		
		String g = "Business";
		if (username.equals("Daniel")) {
			g = "Admin";
		} 
		else if (username.equals("Vivian")) {
			g = "Lead";
		} else {
			g = "Member";
		}
		return g;
	}

	public int getTeamTokenNo(String teamname) {
		// TODO Auto-generated method stub
		return 0;
	}

	public String updateTeamTokenNo(String teamname) {
		// TODO Auto-generated method stub
		return null;
	}

	public String getAllTeamTokenNos() {
		// TODO Auto-generated method stub
		return null;
	}

}
